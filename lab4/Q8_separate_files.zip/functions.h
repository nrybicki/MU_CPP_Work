#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
int CheckOrder(int num1, int num2, int num3, int num4);
int CheckOrder(const std::string& num1, const std::string& num2, const std::string& num3, const std::string& num4);
int CheckOrder(double num1, double num2, double num3, double num4);
int CheckOrder(char num1, char num2, char num3, char num4);

#endif